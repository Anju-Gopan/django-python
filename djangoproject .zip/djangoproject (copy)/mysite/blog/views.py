from django.shortcuts import render
from django.shortcuts import redirect
from blog.models import *

# Create your views here.

def index(request):
    return render(request, 'index.html', {})

def home(request):
    name = request.session['user']
    ids = request.session['id']
    print(name)
    datas = Blog.objects.filter(user__name=name).values()
    print(datas)
    return render(request, 'home.html', {"name":name,"datas":datas})


def login(request):
    return render(request, 'login.html', {})

def register(request):
    return render(request, 'register.html', {})

def post(request):
    return render(request, 'post.html', {})
    


def registrationSave(request):

	
    name = request.POST.get("name", "")
    gmail = request.POST.get("gmail", "")
    phone = request.POST.get("phone", "")
    password = request.POST.get("password", "")

    reg = Registration()
    reg.name = name
    reg.gmail = gmail
    reg.phone = phone
    reg.password = password
    reg.save()

    print(name)
    print(gmail)
    print(phone)
    print(password)
    return redirect('login')

def signin(request):

	
    name = request.POST.get("name", "")
    password = request.POST.get("password", "")
    try:
    	x = Registration.objects.get(name=name,password=password)
        request.session['user'] = x.name
        request.session['id'] = x.id
    except:
        x = False
    print(x)
    
    if x:
    	return redirect('home')
    else:
   	return redirect('login')


def postSave(request):

	
    user = request.session['user']
    print(user)
    title = request.POST.get("title", "")
    body = request.POST.get("body", "")
    user = Registration.objects.get(name=user)
    pos = Blog()
    pos.user = user
    pos.title = title
    pos.body = body
    print(title)
    print(body)
    pos.save()
    return redirect('home')

def logout(request):
    request.session.flush()
    return redirect('login')




